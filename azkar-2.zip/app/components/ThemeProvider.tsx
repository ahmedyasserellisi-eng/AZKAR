"use client";

import { useEffect } from "react";
import { getFontScale, getTheme } from "@/lib/storage";

function applyThemeAndScale() {
  const theme = getTheme();
  const scale = getFontScale();
  const root = document.documentElement;
  const dark = theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  root.classList.toggle("dark", dark);
  root.style.setProperty("--azkar-font-scale", String(scale));
}

export default function ThemeProvider({ children }: { children: React.ReactNode }) {
  useEffect(() => {
    applyThemeAndScale();
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => applyThemeAndScale();
    media.addEventListener?.("change", apply);
    return () => media.removeEventListener?.("change", apply);
  }, []);
  return <>{children}</>;
}
