"use client";

import { useEffect, useState } from "react";
import { BookIcon, MoonIcon, SettingsIcon, SunIcon, CheckIcon } from "../components/Icons";
import { getFontScale, getTheme, setFontScale, setTheme } from "@/lib/storage";

type Theme = "system" | "light" | "dark";

const MIN_SCALE = 0.9;
const MAX_SCALE = 1.25;
const STEP = 0.05;

function clampScale(value: number) {
  return Math.min(MAX_SCALE, Math.max(MIN_SCALE, Number(value.toFixed(2))));
}

function applyPreview(theme: Theme, scale: number) {
  const root = document.documentElement;
  const dark = theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  root.classList.toggle("dark", dark);
  root.style.setProperty("--azkar-font-scale", String(scale));
}

export default function SettingsPage() {
  const [theme, setThemeState] = useState<Theme>("system");
  const [scale, setScale] = useState(1);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const savedTheme = getTheme();
    const savedScale = getFontScale();
    setThemeState(savedTheme);
    setScale(savedScale);
    applyPreview(savedTheme, savedScale);
  }, []);

  function selectTheme(next: Theme) {
    setThemeState(next);
    setSaved(false);
    applyPreview(next, scale);
  }

  function changeScale(delta: number) {
    const next = clampScale(scale + delta);
    setScale(next);
    setSaved(false);
    applyPreview(theme, next);
  }

  function saveSettings() {
    setTheme(theme);
    setFontScale(scale);
    applyPreview(theme, scale);
    setSaved(true);
  }

  return <div className="container-mobile pt-8 sm:pt-12">
    <div className="mb-8">
      <div className="mb-2 flex items-center gap-3"><SettingsIcon size={24} /><h1 className="text-3xl font-bold">الإعدادات</h1></div>
      <p className="text-sm text-[var(--muted)]">خصص تجربة القراءة واحفظ اختياراتك على جهازك.</p>
    </div>

    <div className="space-y-4">
      <section className="card p-5">
        <h2 className="mb-4 font-semibold">المظهر</h2>
        <div className="grid grid-cols-3 gap-2">
          {(["system", "light", "dark"] as Theme[]).map(t => <button key={t} onClick={() => selectTheme(t)} className={`focus-ring rounded-2xl border px-3 py-3 text-sm ${theme === t ? "border-[var(--primary)] bg-[var(--surface-soft)] text-[var(--primary)]" : ""}`} style={{ borderColor: theme === t ? "var(--primary)" : "var(--border)" }}>{t === "system" ? "النظام" : t === "light" ? <span className="inline-flex items-center gap-2"><SunIcon size={17} />فاتح</span> : <span className="inline-flex items-center gap-2"><MoonIcon size={17} />داكن</span>}</button>)}
        </div>
      </section>

      <section className="card p-5">
        <h2 className="mb-4 font-semibold">حجم النص</h2>
        <div className="flex items-center gap-3">
          <button disabled={scale <= MIN_SCALE} onClick={() => changeScale(-STEP)} className="focus-ring rounded-2xl border px-4 py-3 disabled:opacity-40" style={{ borderColor: "var(--border)" }} aria-label="تصغير النص">A−</button>
          <div className="h-2 flex-1 overflow-hidden rounded-full progress-track"><div className="progress-fill h-full rounded-full" style={{ width: `${((scale - MIN_SCALE) / (MAX_SCALE - MIN_SCALE)) * 100}%` }} /></div>
          <button disabled={scale >= MAX_SCALE} onClick={() => changeScale(STEP)} className="focus-ring rounded-2xl border px-4 py-3 disabled:opacity-40" style={{ borderColor: "var(--border)" }} aria-label="تكبير النص">A+</button>
        </div>
        <p className="mt-3 text-center text-xs text-[var(--muted)]">{Math.round(scale * 100)}%</p>
        <p className="mt-2 text-center text-xs text-[var(--muted)]">يتم تطبيق حجم الخط على نص الذكر أثناء القراءة.</p>
      </section>

      <button onClick={saveSettings} className="focus-ring flex w-full items-center justify-center gap-2 rounded-2xl bg-[var(--primary)] px-5 py-4 font-semibold text-white shadow-lg shadow-black/5">
        {saved ? <><CheckIcon size={19} /> تم حفظ الإعدادات</> : "حفظ الإعدادات"}
      </button>

      <section className="card p-5"><div className="flex items-start gap-3"><div className="rounded-2xl soft p-3 text-[var(--primary)]"><BookIcon /></div><div><h2 className="font-semibold">عن أذكار</h2><p className="mt-1 leading-7 text-[var(--muted)]">نسخة أولى خفيفة وسريعة، تحفظ تقدمك ومفضلاتك على جهازك بدون حساب.</p><p className="mt-4 text-xs text-[var(--muted)]">الإصدار 0.1.0</p></div></div></section>
    </div>
  </div>;
}
